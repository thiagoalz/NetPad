/*
* Copyright (C) The Community OpenORB Project. All rights reserved.
*
* This software is published under the terms of The OpenORB Community Software
* License version 1.0, a copy of which has been included with this distribution
* in the LICENSE.txt file.
*/

package org.openorb.event.examples;

/**
 * PullServer example implementation
 * 
 * @author  Jerome Daniel 
 * @author  Olivier Modica
 */
public class PullServer
{
    public static void main( String args [] )
    {
        org.omg.CORBA.Object obj = null;
        org.omg.CosEventChannelAdmin.EventChannel canal = null;

        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init( args, null );

        org.omg.PortableServer.POA rootPOA = null;

        try
        {
            obj = orb.resolve_initial_references( "RootPOA" );
        }
        catch ( org.omg.CORBA.ORBPackage.InvalidName ex )
        {
            ex.printStackTrace();
            System.exit( 1 );
        }

        rootPOA = org.omg.PortableServer.POAHelper.narrow( obj );

        try
        {
            rootPOA.the_POAManager().activate();
        }
        catch ( java.lang.Exception ex )
        {
            System.out.println( "Internal error..." );
            ex.printStackTrace();
        }


        System.out.println( "Event Service example" );
        System.out.println( "Pull model / server side" );

        try
        {
            obj = orb.string_to_object( "corbaname:rir:#COS/EventService/EventChannelFactory" );
        }
        catch ( org.omg.CORBA.BAD_PARAM ex )
        {
            System.out.println( "The EventService cannot be found." );
            System.out.println( "Check if the Event and Naming servers are running." );
            System.exit( -1 );
        }

        if ( obj == null )
        {
            System.out.println( "The EventService reference is incorrect." );
            System.out.println( "Check if the Event and Naming servers are running." );
            System.exit( -1 );
        }

        try
        {
            canal = org.openorb.event.EventChannelFactoryHelper.narrow( obj ).create_channel( "ExampleChannel" );
        }
        catch ( org.openorb.event.NameAlreadyUsed ex )
        {
            try
            {
                canal = org.openorb.event.EventChannelFactoryHelper.narrow( obj ).join_channel( "ExampleChannel" );
            }
            catch ( java.lang.Throwable error )
            {
                error.printStackTrace();
                System.exit( -1 );
            }
        }

        org.omg.CosEventChannelAdmin.SupplierAdmin supplierAdmin = canal.for_suppliers();
        org.omg.CosEventChannelAdmin.ProxyPullConsumer consumer = supplierAdmin.obtain_pull_consumer();

        myPullSupplier supplier = new myPullSupplier( orb, consumer );
        // orb.connect( supplier );

        try
        {
            consumer.connect_pull_supplier( supplier._this( orb ) );
        }
        catch ( java.lang.Exception ex_connect )
        {
            System.out.println( "Unable to connect to supplier" );
            ex_connect.printStackTrace();
        }

        orb.run();
    }
}
