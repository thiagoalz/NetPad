/*
* Copyright (C) The Community OpenORB Project. All rights reserved.
*
* This software is published under the terms of The OpenORB Community Software
* License version 1.0, a copy of which has been included with this distribution
* in the LICENSE.txt file.
*/

package org.openorb.event.examples;

/**
 * PushClient example implementation
 * 
 * @author  Jerome Daniel 
 * @author  Olivier Modica
 */
public class PushClient
{
    public static void main( String args [] )
    {
        org.omg.CORBA.Object obj = null;
        org.omg.CosEventChannelAdmin.EventChannel canal = null;

        System.out.println( "Event Service example" );
        System.out.println( "Push model / client side" );

        org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init( args, null );
        org.omg.PortableServer.POA rootPOA = null;

        try
        {
            obj = orb.resolve_initial_references( "RootPOA" );
        }
        catch ( org.omg.CORBA.ORBPackage.InvalidName ex )
        {
            ex.printStackTrace();
            System.exit( 1 );
        }

        rootPOA = org.omg.PortableServer.POAHelper.narrow( obj );


        try
        {
            rootPOA.the_POAManager().activate();
        }
        catch ( java.lang.Exception ex )
        {
            System.out.println( "Internal error..." );
            ex.printStackTrace();
        }

        try
        {
            obj = orb.string_to_object( "corbaname:rir:#COS/EventService/EventChannelFactory" );
        }
        catch ( org.omg.CORBA.BAD_PARAM ex )
        {
            System.out.println( "The EventService cannot be found." );
            System.out.println( "Check if the Event and Naming servers are running." );
            System.exit( -1 );
        }

        if ( obj == null )
        {
            System.out.println( "The EventService reference is incorrect." );
            System.out.println( "Check if the Event and Naming servers are running." );
            System.exit( -1 );
        }

        try
        {
            canal = org.openorb.event.EventChannelFactoryHelper.narrow( obj ).create_channel( "ExampleChannel" );
        }
        catch ( org.openorb.event.NameAlreadyUsed ex )
        {
            try
            {
                canal = org.openorb.event.EventChannelFactoryHelper.narrow( obj ).join_channel( "ExampleChannel" );
            }
            catch ( java.lang.Throwable error )
            {
                error.printStackTrace();
                System.exit( -1 );
            }
        }

        org.omg.CosEventChannelAdmin.ConsumerAdmin consumerAdmin = canal.for_consumers();
        org.omg.CosEventChannelAdmin.ProxyPushSupplier supplier = consumerAdmin.obtain_push_supplier();

        myPushConsumer consumer = new myPushConsumer( supplier );
        // orb.connect( consumer );

        try
        {
            supplier.connect_push_consumer( consumer._this( orb ) );
        }
        catch ( java.lang.Exception ex_connect )
        {
            System.out.println( "Unable to connect to consumer" );
            ex_connect.printStackTrace();
        }

        orb.run();

    }
}
