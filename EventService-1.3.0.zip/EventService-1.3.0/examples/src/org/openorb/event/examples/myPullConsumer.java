/*
* Copyright (C) The Community OpenORB Project. All rights reserved.
*
* This software is published under the terms of The OpenORB Community Software
* License version 1.0, a copy of which has been included with this distribution
* in the LICENSE.txt file.
*/

package org.openorb.event.examples;

/**
 * PullConsumer example implementation
 * 
 * @author  Jerome Daniel 
 * @author  Olivier Modica
 */
class myPullConsumer
    extends org.omg.CosEventComm.PullConsumerPOA
    implements Runnable
{
    /**
     * Reference to consumer
     */
    private org.omg.CosEventComm.PullSupplier supplier;

    /**
     * Constructor
     */
    public myPullConsumer( org.omg.CosEventComm.PullSupplier supplier )
    {
        this.supplier = supplier;
    }

    /**
     * Disconnect from consumer
     */
    public void disconnect_pull_consumer()
    {
        supplier.disconnect_pull_supplier();

        supplier = null;
    }

    /**
     * Begin runtime
     */
    public void run()
    {
        while ( true )
        {
            org.omg.CORBA.Any any = null;

            try
            {
                any = supplier.pull();
            }
            catch ( java.lang.Exception ex )
            {
                System.out.println( "End of PullConsumer" );
                return ;
            }

            String s = any.extract_string();
            System.out.println( "Received : " + s );

        }
    }
}
