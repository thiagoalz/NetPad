/*
* Copyright (C) The Community OpenORB Project. All rights reserved.
*
* This software is published under the terms of The OpenORB Community Software
* License version 1.0, a copy of which has been included with this distribution
* in the LICENSE.txt file.
*/

package org.openorb.event.examples;

/**
 * PullSupplier example implementation
 * 
 * @author  Jerome Daniel 
 * @author  Olivier Modica
 */
class myPullSupplier
    extends org.omg.CosEventComm.PullSupplierPOA
{
    /**
     * Reference to the ORB
     */
    private org.omg.CORBA.ORB orb;

    /**
     * Message counter
     */
    private int count;

    /**
     * Reference to consumer
     */
    private org.omg.CosEventComm.PullConsumer consumer;

    /**
     * Constructor
     */
    public myPullSupplier( org.omg.CORBA.ORB orb, org.omg.CosEventComm.PullConsumer consumer )
    {
        this.orb = orb;
        this.consumer = consumer;
        count = 0;
    }

    /**
     * Disconnect from supplier
     */
    public void disconnect_pull_supplier()
    {
        consumer.disconnect_pull_consumer();

        consumer = null;
    }

    /**
     * Ask for event
     */
    public org.omg.CORBA.Any pull()
    {
        org.omg.CORBA.Any any = orb.create_any();

        any.insert_string( "This is the event number " + count + "." );

        count++;

        return any;
    }

    /**
     * Ask is any event is available
     */
    public org.omg.CORBA.Any try_pull( org.omg.CORBA.BooleanHolder hasEvent )
    {
        hasEvent.value = true;

        return pull();
    }
}
